#!/usr/bin/env bash
# Install Shelly under a prefix: built from this source checkout, or prebuilt from a release tarball.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: ./install.sh [options]

In a source checkout, builds Shelly in release mode in build-release/ and
installs it. In a release tarball made by package.sh, installs the prebuilt
tree the tarball carries.

Options:
  --prefix DIR   Install prefix (default: /usr/local). A release tarball installs
                 only into the prefix it was built for.
  --skip-deps    Do not check for or install dependencies
  --noconfirm    Install missing packages without asking for confirmation
  --skip-build   Install the tree already staged in build-release/stage without rebuilding
  --stage-only   Build and stage the tree in build-release/stage, then stop without installing
  --restart      After installing, restart the running Shelly (Hyprland sessions only)
  -h, --help     Show this help

--skip-build and --stage-only apply to a source checkout only.

sudo is used only where root is needed: installing missing packages (Arch Linux
only) and copying files into a prefix the current user cannot write to.
EOF
}

die() {
  echo "error: $*" >&2
  exit 1
}

step() {
  printf '\n==> %s\n' "$*"
}

prefix=""
prefix_given=false
skip_deps=false
noconfirm=false
skip_build=false
stage_only=false
restart=false

while (($# > 0)); do
  case "$1" in
    --prefix)
      (($# >= 2)) || die "--prefix needs a directory"
      prefix="$2"
      prefix_given=true
      shift 2
      ;;
    --prefix=*)
      prefix="${1#--prefix=}"
      prefix_given=true
      shift
      ;;
    --skip-deps)
      skip_deps=true
      shift
      ;;
    --noconfirm)
      noconfirm=true
      shift
      ;;
    --skip-build)
      skip_build=true
      shift
      ;;
    --stage-only)
      stage_only=true
      shift
      ;;
    --restart)
      restart=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      die "unknown option: $1"
      ;;
  esac
done

((EUID != 0)) || die "run this as your own user; it calls sudo for the steps that need root"

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$script_dir"

# package.sh ships this script in a release tarball, next to the prebuilt tree (files/) and the
# prefix that tree was built for (PREFIX).
if [[ -f meson.build && -f VERSION ]]; then
  from_tarball=false
elif [[ -f PREFIX && -x files/bin/shelly ]]; then
  from_tarball=true
else
  die "$script_dir is neither a Shelly source checkout nor an extracted Shelly release tarball"
fi

if $from_tarball && { $skip_build || $stage_only; }; then
  die "--skip-build and --stage-only apply to a source checkout only"
fi
if $stage_only && $skip_build; then
  die "--stage-only with --skip-build has nothing to do"
fi
if $stage_only && $restart; then
  die "--stage-only installs nothing, so there is nothing to --restart"
fi

if ! $prefix_given; then
  if $from_tarball; then
    prefix="$(<PREFIX)"
  else
    prefix="/usr/local"
  fi
fi
[[ "$prefix" == /* ]] || die "--prefix must be an absolute path: $prefix"
prefix="${prefix%/}"
[[ -n "$prefix" ]] || die "--prefix must not be the filesystem root"

# The prefix is compiled into the binary, so a prebuilt tree cannot move to another one.
if $from_tarball && [[ "$prefix" != "$(<PREFIX)" ]]; then
  die "this tarball was built for prefix $(<PREFIX); build one for $prefix with: ./package.sh --prefix $prefix"
fi

# Checked before the build so a long compile does not end in a restart that cannot happen.
if $restart; then
  [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]] \
    || die "--restart starts Shelly through hyprctl; run it from a terminal inside the Hyprland session"
  hyprctl version >/dev/null 2>&1 || die "--restart: hyprctl cannot reach Hyprland"
fi

build_dir="$script_dir/build-release"
stage_dir="$build_dir/stage"
if $from_tarball; then
  staged_prefix="$script_dir/files"
else
  staged_prefix="$stage_dir$prefix"
fi
manifest_rel="share/shelly/install-manifest.txt"

# Spelled out in the hints this script prints when the prefix is not the default.
prefix_flag=""
[[ "$prefix" == "/usr/local" ]] || prefix_flag=" --prefix $prefix"

# Arch Linux packages; BUILDING.md lists the other distributions. The runtime ones hold the
# libraries the binary links against and the services it talks to.
arch_runtime_packages=(
  wayland
  libglvnd freetype2 fontconfig
  cairo pango harfbuzz
  libxkbcommon glib2
  libsecret libsodium
  sdbus-cpp libpipewire wireplumber polkit
  pam curl libwebp libjxl libsndfile librsvg
  libqalculate libxml2
  md4c tomlplusplus libical
  jemalloc
)
arch_build_packages=(
  meson ninja gcc pkgconf
  wayland-protocols
  nlohmann-json stb
)

check_dependencies() {
  local packages=("${arch_runtime_packages[@]}")
  if $from_tarball; then
    step "Checking runtime dependencies"
  else
    step "Checking build dependencies"
    packages+=("${arch_build_packages[@]}")
  fi

  if command -v pacman >/dev/null 2>&1; then
    local missing=()
    mapfile -t missing < <(pacman -T "${packages[@]}" || true)
    if ((${#missing[@]} > 0)); then
      echo "Missing packages: ${missing[*]}"
      local confirm=()
      if $noconfirm; then
        confirm=(--noconfirm)
      fi
      sudo pacman -S --needed "${confirm[@]}" "${missing[@]}"
    else
      echo "All required packages are installed."
    fi

    # Shelly is not a pacman package, so pacman does not know that Shelly needs these. A package
    # installed only as a dependency is removed by an orphan cleanup, or by `pacman -Rs` on the
    # last package that requires it. Mark them as explicitly installed so both keep them.
    local as_dependency=()
    mapfile -t as_dependency < <(
      LC_ALL=C comm -12 \
        <( (pacman -Qdq || true) | LC_ALL=C sort) \
        <(printf '%s\n' "${packages[@]}" | LC_ALL=C sort)
    )
    if ((${#as_dependency[@]} > 0)); then
      echo "Marking as explicitly installed (required by Shelly): ${as_dependency[*]}"
      sudo pacman -D --asexplicit "${as_dependency[@]}"
    fi
  fi

  if ! $from_tarball; then
    local tool
    for tool in meson ninja c++ pkg-config wayland-scanner; do
      command -v "$tool" >/dev/null 2>&1 \
        || die "'$tool' was not found; install the build dependencies listed in BUILDING.md"
    done
  fi
}

build() {
  step "Configuring build-release/ for prefix $prefix"
  local args=(--buildtype=release -Dcpp_std=c++23 -Db_lto=true -Dtests=auto --prefix "$prefix")
  if [[ -f "$build_dir/build.ninja" ]]; then
    meson setup "$build_dir" "${args[@]}" --reconfigure || meson setup "$build_dir" "${args[@]}" --wipe
  else
    meson setup "$build_dir" "${args[@]}"
  fi

  step "Compiling"
  meson compile -C "$build_dir" shelly
}

stage() {
  step "Staging the install tree"
  rm -rf "$stage_dir"
  meson install --no-rebuild --quiet -C "$build_dir" --destdir "$stage_dir"
  [[ -x "$staged_prefix/bin/shelly" ]] || die "staging did not produce $staged_prefix/bin/shelly"

  # Shell completions, generated by the binary that was just built.
  local completions
  completions="$(mktemp -d)"
  "$staged_prefix/bin/shelly" completions bash >"$completions/bash"
  "$staged_prefix/bin/shelly" completions zsh >"$completions/zsh"
  "$staged_prefix/bin/shelly" completions fish >"$completions/fish"
  install -Dm644 "$completions/bash" "$staged_prefix/share/bash-completion/completions/shelly"
  install -Dm644 "$completions/zsh" "$staged_prefix/share/zsh/site-functions/_shelly"
  install -Dm644 "$completions/fish" "$staged_prefix/share/fish/vendor_completions.d/shelly.fish"
  rm -rf "$completions"

  install -Dm644 "$script_dir/LICENSE" "$staged_prefix/share/licenses/shelly/LICENSE"

  # Every installed file, relative to the prefix. uninstall.sh removes exactly this list.
  # The empty placeholder makes the manifest list itself.
  local list
  list="$(mktemp)"
  install -Dm644 /dev/null "$staged_prefix/$manifest_rel"
  (cd "$staged_prefix" && find . \( -type f -o -type l \) -print | LC_ALL=C sort) >"$list"
  install -m644 "$list" "$staged_prefix/$manifest_rel"
  rm -f "$list"
}

# Refuses a binary the dynamic loader cannot satisfy: a library is missing, or is older than the
# one the binary was linked against. A prebuilt binary carries the library versions of the
# machine that built it.
check_libraries() {
  command -v ldd >/dev/null 2>&1 || return 0
  local unresolved
  unresolved="$(ldd "$staged_prefix/bin/shelly" 2>&1 | grep -F 'not found' || true)"
  [[ -n "$unresolved" ]] || return 0

  echo "The dynamic loader cannot satisfy $staged_prefix/bin/shelly:" >&2
  echo "$unresolved" >&2
  if $from_tarball; then
    die "this tarball does not match the libraries on this machine; install the ones it names, or build Shelly here from source"
  fi
  die "the staged build does not match the libraries on this machine; run ./install.sh without --skip-build"
}

# Prints "sudo" when the prefix (or its nearest existing parent) is not writable.
root_command() {
  local probe="$prefix"
  while [[ ! -e "$probe" ]]; do
    probe="$(dirname "$probe")"
  done
  if [[ ! -w "$probe" ]]; then
    echo sudo
  fi
}

install_tree() {
  if [[ ! -x "$staged_prefix/bin/shelly" || ! -f "$staged_prefix/$manifest_rel" ]]; then
    if $from_tarball; then
      die "$script_dir is not a complete release tarball: files/$manifest_rel is missing"
    fi
    die "nothing is staged for prefix $prefix; run ./install.sh without --skip-build"
  fi
  check_libraries

  step "Installing into $prefix"
  local root=()
  mapfile -t root < <(root_command)
  if ((${#root[@]} > 0)); then
    echo "$prefix is not writable by $USER; using sudo."
  fi

  # Files a previous install put here that this version no longer ships.
  local old_manifest="$prefix/$manifest_rel"
  if [[ -f "$old_manifest" ]]; then
    local stale=()
    mapfile -t stale < <(LC_ALL=C comm -23 <(LC_ALL=C sort "$old_manifest") <(LC_ALL=C sort "$staged_prefix/$manifest_rel"))
    local entry
    for entry in "${stale[@]}"; do
      [[ "$entry" == ./* && "$entry" != *"/../"* && "$entry" != */.. ]] || die "refusing manifest entry: $entry"
      "${root[@]}" rm -f -- "$prefix/${entry#./}"
    done
    if ((${#stale[@]} > 0)); then
      echo "Removed ${#stale[@]} file(s) left over from the previous install."
    fi
  fi

  # Copy files only, so existing directories keep their owner and mode.
  "${root[@]}" mkdir -p "$prefix"
  tar -C "$staged_prefix" -cf - -T "$staged_prefix/$manifest_rel" \
    | "${root[@]}" tar -C "$prefix" --no-same-owner -xf -

  if command -v update-desktop-database >/dev/null 2>&1; then
    "${root[@]}" update-desktop-database -q "$prefix/share/applications" || true
  fi

  local count
  count="$(wc -l <"$staged_prefix/$manifest_rel")"
  echo "Installed $count files: $("$prefix/bin/shelly" --version)"
}

shelly_running() {
  pgrep -x -u "$EUID" shelly >/dev/null
}

shelly_stopped() {
  ! shelly_running
}

shelly_answers() {
  "$prefix/bin/shelly" msg status >/dev/null 2>&1
}

# True while the session lock is held. Shelly owns the lock surface, so stopping it then
# would leave the screen locked with nothing able to unlock it.
session_locked() {
  local status
  if status="$("$prefix/bin/shelly" msg status 2>/dev/null)"; then
    grep -Eq '"locked":[[:space:]]*true' <<<"$status"
    return
  fi
  [[ "$(loginctl show-session "${XDG_SESSION_ID:-self}" -p LockedHint --value 2>/dev/null)" == "yes" ]]
}

# wait_for <seconds> <command...>: poll until the command succeeds.
wait_for() {
  local deadline=$((SECONDS + $1))
  shift
  until "$@"; do
    ((SECONDS < deadline)) || return 1
    sleep 0.2
  done
}

restart_shelly() {
  step "Restarting Shelly"
  if session_locked; then
    local rerun="./install.sh --skip-build --restart${prefix_flag}"
    if $from_tarball; then
      rerun="./install.sh --restart"
    fi
    echo "The session is locked, so the running Shelly was left alone." >&2
    echo "Unlock, then run: $rerun" >&2
    exit 1
  fi

  if shelly_running; then
    pkill -x -u "$EUID" shelly || true
    wait_for 10 shelly_stopped \
      || die "the running Shelly did not exit within 10 seconds; not starting a second instance"
  fi

  # exec_cmd runs its argument through a shell, inside a Lua string literal.
  local shell_quoted lua_quoted output
  printf -v shell_quoted '%q' "$prefix/bin/shelly"
  lua_quoted="${shell_quoted//\\/\\\\}"
  lua_quoted="${lua_quoted//\"/\\\"}"
  output="$(hyprctl dispatch "hl.dsp.exec_cmd(\"$lua_quoted\")" 2>&1)" || true
  [[ "$output" == "ok" ]] || die "hyprctl could not start Shelly: $output"

  wait_for 10 shelly_answers \
    || die "Shelly was started but is not answering; see ${XDG_CACHE_HOME:-$HOME/.cache}/shelly/shelly.log"
  echo "Shelly is running (pid $(pgrep -x -u "$EUID" shelly | head -1))."
}

if $from_tarball; then
  $skip_deps || check_dependencies
elif ! $skip_build; then
  $skip_deps || check_dependencies
  build
  stage
fi

if $stage_only; then
  printf '\nStaged in %s. Nothing was installed.\n' "$staged_prefix"
  exit 0
fi

install_tree

# example.toml is part of the source checkout, not of a release tarball.
config_reference=" (see example.toml)"
if $from_tarball; then
  config_reference=""
fi

cat <<EOF

Shelly is installed at $prefix/bin/shelly.
  Start it from your compositor's autostart with: shelly
  Configuration lives in ~/.config/shelly/config.toml$config_reference.
  Remove it again with: ./uninstall.sh$prefix_flag
EOF

if $restart; then
  restart_shelly
fi
