# Shelly

A lean desktop shell for Wayland compositors: a bar with fifteen widgets and their popups, an application launcher with a calculator, clipboard history, notifications and an on-screen display, wallpapers with shader transitions, a lock screen, idle and power handling, and night light. A separate Settings app configures all of it, live.

Shelly is built for **Hyprland**, **niri** and **MangoWM**, and works with reduced features on other compositors that offer `wlr-layer-shell` (the lock screen also needs `ext-session-lock-v1`). It is written in C++20 with GTK 4 (through gtkmm, without libadwaita) and gtk4-layer-shell, and borrows its behaviour from [Noctalia](https://github.com/noctalia-dev/noctalia) v5, whose MIT-licensed code it ports in parts (see `THIRD_PARTY_NOTICES.md`).

What Shelly does, and what it deliberately does not, is defined in `docs/requirements.md`. Every setting is listed in `docs/CONFIG.md`.

## Dependencies

GTK must be 4.16 or newer, gtk4-layer-shell 1.1 or newer, wayland-protocols 1.39 or newer, and the compiler must speak C++20 (GCC 13 or Clang 17 and later; Shelly is developed with GCC 15).

| | Needed for |
|---|---|
| gtkmm-4.0, gtk4-layer-shell, wayland-client, wayland-protocols, wayland-scanner, toml++, fontconfig, nlohmann/json, xkbcommon, libepoxy | Building at all |
| WirePlumber 0.5 (and PipeWire) | Audio widget and OSD |
| libsoup 3, and glib-networking at run time | Weather (HTTPS to Open-Meteo) |
| libqalculate | The launcher's calculator |
| PAM | The lock screen's password check (`shelly-pam-helper`) |
| libudev, libevdev | Game controllers keeping the screen on |
| Catch2 3 | The unit tests (optional) |
| Python 3, Meson ≥ 1.1, Ninja | The build |

At run time Shelly talks to **logind** (systemd or elogind), **UPower**, **NetworkManager** and **BlueZ**; **power-profiles-daemon**, **AccountsService** and **fprintd** are used when present. A missing service hides or disables what depends on it. WebP wallpapers need `webp-pixbuf-loader` (or a gdk-pixbuf built with glycin).

### Debian and Ubuntu

Checked on Ubuntu 26.04:

```sh
sudo apt install build-essential pkg-config meson ninja-build \
  libgtkmm-4.0-dev libgtk4-layer-shell-dev libwayland-dev libwayland-bin wayland-protocols \
  libtomlplusplus-dev nlohmann-json3-dev libfontconfig-dev libxkbcommon-dev libepoxy-dev \
  libwireplumber-0.5-dev libsoup-3.0-dev glib-networking libqalculate-dev \
  libpam0g-dev libudev-dev libevdev-dev libcatch2-dev
```

Older releases may lack gtk4-layer-shell or ship a GTK older than 4.16.

### Arch Linux

```sh
sudo pacman -S --needed base-devel meson ninja gtkmm-4.0 gtk4-layer-shell wayland wayland-protocols \
  tomlplusplus nlohmann-json fontconfig libxkbcommon libepoxy wireplumber libsoup3 glib-networking \
  libqalculate pam systemd-libs libevdev catch2
```

### Fedora

Not checked on Fedora; the names follow its usual `-devel` scheme:

```sh
sudo dnf install gcc-c++ meson ninja-build gtkmm4.0-devel gtk4-layer-shell-devel wayland-devel \
  wayland-protocols-devel tomlplusplus-devel json-devel fontconfig-devel libxkbcommon-devel libepoxy-devel \
  wireplumber-devel libsoup3-devel glib-networking libqalculate-devel pam-devel systemd-devel \
  libevdev-devel catch-devel
```

If a package name is wrong for your release, the error from `meson setup` names the pkg-config module it is missing (`gtkmm-4.0`, `libqalculate`, …); install whatever provides it.

## Build, test and install

```sh
meson setup build
meson compile -C build
meson test -C build        # unit tests, command line, link order, CONFIG.md freshness
sudo meson install -C build
```

The build treats warnings as errors. If a newer compiler stops it with a warning, configure with `-Dwerror=false` and report the warning.

`meson install` puts in place `shelly` and `shelly-settings` (in `bin`), `shelly-pam-helper` (in `libexec`, started by the shell; not for you to run), the data directory (`share/shelly`: stylesheets, the icon font, the launcher's bundled SVGs; the transition shaders are compiled in), the Settings desktop entry and icon, and the **PAM service file** `pam.d/shelly` under `sysconfdir`. PAM reads `/etc/pam.d` only, so configure with `--prefix=/usr --sysconfdir=/etc` for a system install, or copy the file there yourself:

```sh
sudo cp data/pam/shelly /etc/pam.d/shelly
```

Without it PAM falls back to `/etc/pam.d/other`, which on many systems refuses every password. The file includes the `login` stack; adjust it if your distribution needs something else.

### With the install script

```sh
./install.sh             # release build in build-release/, installed into /usr/local
./install.sh --restart   # … and the running shell replaced by the new one
```

`install.sh` does the steps above for you: it first installs the missing dependencies with pacman, apt or dnf (the lists above without Catch2; `--no-deps` skips this, `--deps-only` stops after it), then builds with `--sysconfdir=/etc` (so the PAM file lands in `/etc/pam.d`), asks for sudo only for what you cannot write, skips unchanged files, and leaves an `/etc/pam.d/shelly` that you changed alone (it shows the difference). `--prefix DIR` installs elsewhere. `--restart` stops the running shell and starts the installed one with the environment and arguments its compositor gave the old one, so it also works over ssh or from a TTY; its output goes to `~/.local/state/shelly/shelly.log`.

### Packaging for another machine

```sh
./package.sh             # dist/shelly-0.1.0-x86_64.tar.gz: prebuilt
./package.sh --source    # dist/shelly-0.1.0-src.tar.gz: the committed sources
```

Either archive carries its own `install.sh`. On the other machine, for example from a dotfiles repository:

```sh
tar -xzf shelly-0.1.0-x86_64.tar.gz && shelly-0.1.0-x86_64/install.sh --restart
```

A prebuilt package needs the libraries of the machine that built it, in practice the same distribution and release, and it installs only into the prefix it was built for (`package.sh --prefix DIR`), because the data directory is compiled in. Its `install.sh` installs the packages that own the libraries the programs link (recorded in the archive's `PACKAGE` file when it was built), then checks the libraries with `ldd` before copying anything. A source package fits any distribution; its `install.sh` installs the build dependencies listed above and builds on the target.

Sanitizers, for development:

```sh
meson setup build-asan -Db_sanitize=address,undefined -Db_lundef=false
meson test -C build-asan
```

## Starting Shelly

Start `shelly` once per session from the compositor. It is a single instance: a second `shelly` prints a message and exits. It finds the compositor from the environment the compositor sets (`HYPRLAND_INSTANCE_SIGNATURE`, `NIRI_SOCKET`, `MANGO_INSTANCE_SIGNATURE`), so it must be started by the compositor or from a terminal inside it.

Stop any other notification daemon (mako, dunst, swaync) first: only one program can own `org.freedesktop.Notifications`. Another bar can keep running, but both will reserve space.

**Hyprland** (`~/.config/hypr/hyprland.conf`):

```ini
exec-once = shelly

misc {
    # Lets a restarted Shelly take over a lock the old one left behind (LOCK-22).
    allow_session_lock_restore = true
}
```

**niri** (`~/.config/niri/config.kdl`):

```kdl
spawn-at-startup "shelly"

// Optional: the wallpaper backdrop shown in the overview (Settings › Wallpaper › Backdrop).
layer-rule {
    match namespace="^shelly-backdrop$"
    place-within-backdrop true
}
```

**MangoWM** (`~/.config/mango/config.conf`):

```ini
exec-once=shelly
```

## Key bindings

These are all of Shelly's commands (`IPC-01`); bind the ones you want in the compositor.

| Command | Does |
|---|---|
| `shelly msg launcher toggle` | Opens or closes the launcher |
| `shelly msg clipboard toggle` | Opens or closes the clipboard history |
| `shelly msg session toggle` | Opens or closes the session panel (lock, log out, suspend, reboot, shut down) |
| `shelly msg wallpaper toggle` | Opens or closes the wallpaper picker |
| `shelly msg lock` | Locks the session |
| `shelly msg settings` | Opens the Settings app, or focuses it |

Panels opened this way appear on the monitor that has focus.

Hyprland:

```ini
bind = SUPER, Space, exec, shelly msg launcher toggle
bind = SUPER, V, exec, shelly msg clipboard toggle
bind = SUPER, Escape, exec, shelly msg session toggle
bind = SUPER, W, exec, shelly msg wallpaper toggle
bind = SUPER, L, exec, shelly msg lock
bind = SUPER, Comma, exec, shelly msg settings
```

niri:

```kdl
binds {
    Mod+Space { spawn "shelly" "msg" "launcher" "toggle"; }
    Mod+V { spawn "shelly" "msg" "clipboard" "toggle"; }
    Mod+Escape { spawn "shelly" "msg" "session" "toggle"; }
    Mod+W { spawn "shelly" "msg" "wallpaper" "toggle"; }
    Mod+L { spawn "shelly" "msg" "lock"; }
    Mod+Comma { spawn "shelly" "msg" "settings"; }
}
```

MangoWM:

```ini
bind=SUPER,space,spawn,shelly msg launcher toggle
bind=SUPER,v,spawn,shelly msg clipboard toggle
bind=SUPER,Escape,spawn,shelly msg session toggle
bind=SUPER,w,spawn,shelly msg wallpaper toggle
bind=SUPER,l,spawn,shelly msg lock
bind=SUPER,comma,spawn,shelly msg settings
```

Volume and brightness keys are the compositor's business: bind them to `wpctl` and `brightnessctl`, and Shelly's OSD shows the change whoever made it.

## Layer namespaces

Every kind of surface has a fixed layer-shell namespace, for compositor layer rules (blur, animations, placement):

| Namespace | Surface | Layer |
|---|---|---|
| `shelly-bar` | The bar, one per monitor | top |
| `shelly-panel` | Popups and panels (calendar, Wi-Fi, audio, battery, Bluetooth, notifications, clipboard, session, wallpaper picker) | overlay |
| `shelly-launcher` | The launcher | overlay |
| `shelly-panel-shield` | The invisible, full-screen surface that closes a panel when you click elsewhere (dims the screen behind centred panels) | top |
| `shelly-toast` | Notification toasts | `[notification] layer` (top by default) |
| `shelly-osd` | The on-screen display | overlay |
| `shelly-wallpaper` | The wallpaper, one per monitor | background |
| `shelly-backdrop` | The blurred wallpaper for niri's overview | background |

The lock screen uses `ext-session-lock-v1`, which has no namespaces.

Match whole names (`^shelly-panel$`): a pattern such as `^shelly-panel` or `shelly-.*` also catches `shelly-panel-shield`, which covers the whole screen while a panel is open, and a blur rule would then blur everything.

## Configuration

Everything is set in **Settings** (`shelly-settings`, or `shelly msg settings`), which writes `~/.config/shelly/config.toml`. The file can also be edited by hand; both the shell and Settings pick changes up within a fraction of a second. `docs/CONFIG.md` lists every key with its default and range, and

```sh
shelly --check-config
```

reports problems with line numbers. A broken file never stops the shell: it keeps the last good configuration and says what is wrong in a notification.

State (clipboard and notification history, usage counts, the chosen wallpaper, the Settings window size) lives in `~/.local/state/shelly/`, caches (thumbnails, weather) in `~/.cache/shelly/`. The only network traffic is to Open-Meteo, for the weather, and only once a location is set.

`shelly --verbose` logs what each service does, one domain per service; `shelly --version` prints the version.

## Development

Run from the build tree without installing: `meson devenv` points `SHELLY_DATA_DIR` at the staged data.

```sh
meson devenv -C build ./src/shelly --verbose
meson devenv -C build ./src/shelly-settings
meson devenv -C build ./src/shelly-gallery     # every component in every state
```

The PAM helper is looked up in the install location; for lock-screen work either install once or start the shell from a directory that has `shelly-pam-helper` beside it (`docs/TESTING.md`, M7).

### In a nested compositor

Shelly can run inside a compositor that itself runs as a window of your normal session, which is the easiest way to try a change without leaving your desktop (`TEST-03`). Start the nested compositor from a terminal, then start Shelly with the nested compositor's environment:

| Compositor | Start it nested | Point Shelly at it |
|---|---|---|
| Hyprland | `Hyprland` from a terminal in your Wayland session opens it in a window | Inside it (a terminal started by its `exec-once`, or its key binding): `meson devenv -C build ./src/shelly`. From outside: `WAYLAND_DISPLAY=wayland-N HYPRLAND_INSTANCE_SIGNATURE=… ./src/shelly`, both read from `hyprctl instances` |
| niri | `niri` from a terminal (its winit backend opens a window) | `WAYLAND_DISPLAY=wayland-N NIRI_SOCKET=$XDG_RUNTIME_DIR/niri.wayland-N.….sock ./src/shelly` (the socket is printed in niri's log) |
| MangoWM | `mango` from a terminal (wlroots' Wayland backend opens a window) | `WAYLAND_DISPLAY=wayland-N MANGO_INSTANCE_SIGNATURE=… ./src/shelly`, as Mango exports them to its children |
| sway (any wlroots compositor; generic backend) | `sway` from a terminal, or headless: `WLR_BACKENDS=headless WLR_RENDERER=pixman sway` | `WAYLAND_DISPLAY=wayland-N ./src/shelly` |

The simplest way to get every variable right is to start a terminal from inside the nested compositor and run Shelly there. A headless sway with `grim` for screenshots is what the automated manual checks in `docs/TESTING.md` use; it has no workspace protocol, so the Workspaces widget is hidden there. python-dbusmock can stand in for UPower, NetworkManager, BlueZ, power-profiles-daemon and logind on a private system bus (`docs/TESTING.md`, M3).

Before committing: `clang-format -i $(find src tests -name '*.cpp' -o -name '*.hpp')`, `meson test`, and `meson compile -C build config-doc` after changing the settings schema.

## Documents

| File | What it holds |
|---|---|
| `docs/requirements.md` | The specification: what Shelly is, requirement by requirement |
| `docs/ARCHITECTURE.md` | Processes, layers, services, surfaces, threading |
| `docs/CONFIG.md` | Every setting (generated from the schema) |
| `docs/DECISIONS.md`, `docs/OPEN_QUESTIONS.md` | Decisions taken, and points waiting for an answer |
| `docs/TESTING.md` | What is tested, how, and what still needs a real machine |
| `docs/STATUS.md` | Every requirement against the definition of done |
| `docs/parity/` | What was taken from the reference, feature by feature |
| `docs/design/DESIGN.md` | Tokens, components and surface layouts |

## Licence

Shelly's own code is MIT-licensed. It links libqalculate, which is GPL-2.0-or-later, so a distributed `shelly` binary falls under the GPL's terms (Q37), and the Settings icon comes from gnome-control-center under GPL-2.0-or-later. Third-party material and its licences are listed in `THIRD_PARTY_NOTICES.md`; the icon font is Tabler Icons (MIT).
