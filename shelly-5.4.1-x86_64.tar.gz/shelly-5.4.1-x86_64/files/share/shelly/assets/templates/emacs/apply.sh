#!/usr/bin/env bash
set -euo pipefail

emacsclient -e "(load-theme 'shelly t)"