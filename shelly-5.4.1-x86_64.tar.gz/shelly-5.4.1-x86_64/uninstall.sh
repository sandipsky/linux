#!/usr/bin/env bash
# Remove a Shelly installation made by install.sh.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: ./uninstall.sh [options]

Removes the files install.sh placed under a prefix, using the manifest it
wrote to <prefix>/share/shelly/install-manifest.txt.

Options:
  --prefix DIR   Install prefix to remove from (default: /usr/local)
  --purge        Also delete this user's Shelly configuration, state, data, and cache
  -h, --help     Show this help

sudo is used only when the prefix is not writable by the current user.
EOF
}

die() {
  echo "error: $*" >&2
  exit 1
}

prefix="/usr/local"
purge=false

while (($# > 0)); do
  case "$1" in
    --prefix)
      (($# >= 2)) || die "--prefix needs a directory"
      prefix="$2"
      shift 2
      ;;
    --prefix=*)
      prefix="${1#--prefix=}"
      shift
      ;;
    --purge)
      purge=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      die "unknown option: $1"
      ;;
  esac
done

[[ "$prefix" == /* ]] || die "--prefix must be an absolute path: $prefix"
prefix="${prefix%/}"
[[ -n "$prefix" ]] || die "--prefix must not be the filesystem root"
((EUID != 0)) || die "run this as your own user; it calls sudo for the steps that need root"

manifest="$prefix/share/shelly/install-manifest.txt"
[[ -f "$manifest" ]] || die "no Shelly install manifest at $manifest; nothing to uninstall under $prefix"

entries=()
mapfile -t entries <"$manifest"
((${#entries[@]} > 0)) || die "$manifest is empty"
for entry in "${entries[@]}"; do
  [[ "$entry" == ./* && "$entry" != *"/../"* && "$entry" != */.. ]] || die "refusing manifest entry: $entry"
done

root=()
if [[ ! -w "$prefix" ]]; then
  root=(sudo)
  echo "$prefix is not writable by $USER; using sudo."
fi

if pgrep -x shelly >/dev/null 2>&1; then
  echo "note: shelly is still running; it keeps running until you stop it or log out."
fi

echo "Removing ${#entries[@]} files from $prefix"
# One rm per batch of paths; directories are handled afterwards.
printf '%s\0' "${entries[@]}" \
  | (cd "$prefix" && xargs -0 -r "${root[@]}" rm -f --)

# Remove the directories the files lived in, deepest first, when they are now empty.
# rmdir refuses non-empty directories, so shared ones such as bin/ and share/ survive.
printf '%s\n' "${entries[@]}" \
  | while IFS= read -r entry; do
    dir="$(dirname "${entry#./}")"
    while [[ "$dir" != "." && "$dir" != "/" ]]; do
      printf '%s\n' "$dir"
      dir="$(dirname "$dir")"
    done
  done \
  | LC_ALL=C sort -u -r \
  | tr '\n' '\0' \
  | (cd "$prefix" && xargs -0 -r "${root[@]}" rmdir --ignore-fail-on-non-empty --)

if command -v update-desktop-database >/dev/null 2>&1 && [[ -d "$prefix/share/applications" ]]; then
  "${root[@]}" update-desktop-database -q "$prefix/share/applications" || true
fi

echo "Shelly was removed from $prefix."

user_dirs=(
  "${XDG_CONFIG_HOME:-$HOME/.config}/shelly"
  "${XDG_STATE_HOME:-$HOME/.local/state}/shelly"
  "${XDG_DATA_HOME:-$HOME/.local/share}/shelly"
  "${XDG_CACHE_HOME:-$HOME/.cache}/shelly"
)

if $purge; then
  for dir in "${user_dirs[@]}"; do
    if [[ -d "$dir" ]]; then
      rm -rf -- "$dir"
      echo "Deleted $dir"
    fi
  done
else
  kept=()
  for dir in "${user_dirs[@]}"; do
    [[ -d "$dir" ]] && kept+=("$dir")
  done
  if ((${#kept[@]} > 0)); then
    echo "Kept your settings and data (pass --purge to delete them):"
    printf '  %s\n' "${kept[@]}"
  fi
fi
