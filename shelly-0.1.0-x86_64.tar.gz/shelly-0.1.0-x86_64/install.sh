#!/usr/bin/env bash
# Installs Shelly (BLD-04), from a source checkout or from a package made by package.sh.
#
#   ./install.sh                     install into /usr/local
#   ./install.sh --restart           ... and replace the running shell with the new one
#
# Beside meson.build (a checkout, or a source package) it configures a release build in
# build-release/, compiles it and installs it (BLD-01). Inside an unpacked binary package
# (shelly-VERSION-ARCH/, which holds PACKAGE and root/) it copies the prebuilt files.
#
# First it installs the packages Shelly needs that are missing, with pacman, apt or dnf
# (--no-deps skips this): the build dependencies for a source tree, and for a binary
# package the libraries package.sh recorded in PACKAGE.
#
# Either way the files are staged first and then copied into place: unchanged files are
# skipped, sudo is asked for only where you cannot write (normally /usr/local and
# /etc/pam.d) and for installing packages, and binaries are replaced by renaming, so a
# running shell does not stop the install. Run it as yourself, not with sudo.

set -euo pipefail

here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

say() { printf '==> %s\n' "$*"; }
note() { printf '    %s\n' "$*"; }
warn() { printf 'install.sh: warning: %s\n' "$*" >&2; }
die() {
  printf 'install.sh: %s\n' "$*" >&2
  exit 1
}

usage() {
  cat <<'EOF'
Usage: install.sh [options]

Installs Shelly: builds it when run from a source tree, copies the prebuilt files when
run from a package made by package.sh.

  --no-deps          do not install missing dependencies with the package manager
  --deps-only        install the missing dependencies and stop
  --restart          afterwards, replace the running shell with the installed one
                     (or start it, when run inside a Wayland session where it is not running)
  --prefix DIR       install prefix (default /usr/local). A prebuilt package installs only
                     into the prefix it was built for.
  --build-dir DIR    build tree for a source install (default: build-release/ beside install.sh)
  --destdir DIR      stage the files into DIR instead of the live system (used by package.sh)
  -h, --help         show this help

The PAM service file always goes to /etc/pam.d/shelly. An existing one that differs is
left alone, since you may have adjusted it.
EOF
}

prefix=""
build_dir=""
destdir=""
restart=0
deps=1
deps_only=0

while [ $# -gt 0 ]; do
  case $1 in
    --restart) restart=1 ;;
    --no-deps) deps=0 ;;
    --deps-only) deps_only=1 ;;
    --prefix | --build-dir | --destdir)
      [ $# -ge 2 ] || die "$1 needs a directory"
      case $1 in
        --prefix) prefix=$2 ;;
        --build-dir) build_dir=$2 ;;
        --destdir) destdir=$2 ;;
      esac
      shift
      ;;
    --prefix=*) prefix=${1#*=} ;;
    --build-dir=*) build_dir=${1#*=} ;;
    --destdir=*) destdir=${1#*=} ;;
    -h | --help)
      usage
      exit 0
      ;;
    *) die "unknown option: $1 (see --help)" ;;
  esac
  shift
done

if [ -n "$prefix" ]; then
  case $prefix in
    /*) ;;
    *) die "--prefix must be an absolute path: $prefix" ;;
  esac
  while [ "$prefix" != / ] && [ "${prefix%/}" != "$prefix" ]; do prefix=${prefix%/}; done
fi
if [ -n "$destdir" ] && [ "$restart" = 1 ]; then
  die "--restart replaces the running shell, which makes no sense with --destdir"
fi
if [ "$deps" = 0 ] && [ "$deps_only" = 1 ]; then
  die "--no-deps and --deps-only contradict each other"
fi
if [ "$(id -u)" = 0 ] && [ "$restart" = 1 ]; then
  die "--restart would start the shell as root; run install.sh as yourself (it asks for sudo when it needs it)"
fi

# ---- Helpers ------------------------------------------------------------------------------

# Runs a command as root: directly when we are root, otherwise through sudo or doas.
as_root() {
  if [ "$(id -u)" = 0 ]; then
    "$@"
  elif command -v sudo >/dev/null 2>&1; then
    sudo "$@"
  elif command -v doas >/dev/null 2>&1; then
    doas "$@"
  else
    die "root is needed (to install packages, or to write the prefix and /etc/pam.d), and neither sudo nor doas is installed"
  fi
}

# True when the user can create $1: its nearest existing ancestor is writable.
writable() {
  local dir=$1
  while [ ! -e "$dir" ]; do dir=$(dirname "$dir"); done
  [ -w "$dir" ]
}

# Copies the files $2... (absolute target paths) from the staged tree $1 into place.
# Each goes to a temporary name in its target directory first and is then renamed over the
# old file, so a running binary is replaced instead of overwritten ("Text file busy").
# Runs under sudo for the files that need root, so it must not use anything else here.
copy_into_place() {
  local stage=$1 target dir tmp mode
  shift
  for target in "$@"; do
    dir=$(dirname "$target")
    install -d -m 755 "$dir"
    case $target in
      */bin/* | */libexec/*) mode=755 ;;
      *) mode=644 ;; # Also when the source looks executable, as everything on /mnt/c does.
    esac
    tmp=$(mktemp "$dir/.shelly-install.XXXXXX")
    install -m "$mode" "$stage$target" "$tmp"
    mv -f "$tmp" "$target"
    printf '    %s\n' "$target"
  done
}

# Copies the staged tree $1 into the live system.
deploy() {
  local stage=$1 file target kept=0
  local -a mine=() root=()
  while IFS= read -r -d '' file; do
    target=${file#"$stage"}
    if [ -e "$target" ] && cmp -s "$file" "$target"; then
      continue
    fi
    case $target in
      */pam.d/*)
        if [ -e "$target" ]; then
          warn "$target differs from Shelly's and was kept (you may have adjusted it). The difference:"
          diff -u "$target" "$file" >&2 || true
          kept=1
          continue
        fi
        ;;
    esac
    if writable "$(dirname "$target")"; then
      mine+=("$target")
    else
      root+=("$target")
    fi
  done < <(find "$stage" -type f -print0 | sort -z)

  if [ ${#mine[@]} -eq 0 ] && [ ${#root[@]} -eq 0 ]; then
    if [ $kept = 1 ]; then
      say "Every other file is already up to date"
    else
      say "Every file is already up to date"
    fi
    return
  fi
  if [ ${#mine[@]} -gt 0 ]; then
    say "Installing ${#mine[@]} files"
    copy_into_place "$stage" "${mine[@]}"
  fi
  if [ ${#root[@]} -gt 0 ]; then
    say "Installing ${#root[@]} files as root"
    as_root bash -c "$(declare -f copy_into_place); copy_into_place \"\$@\"" bash "$stage" "${root[@]}"
  fi
}

# Refreshes the hicolor icon cache for the Settings icon, if that theme directory keeps one.
# A cache that is not refreshed hides the new icon; where there is none, GTK scans the files.
refresh_icon_cache() {
  local dir=$prefix/share/icons/hicolor
  [ -f "$dir/icon-theme.cache" ] || return 0
  command -v gtk-update-icon-cache >/dev/null 2>&1 || return 0
  if [ -w "$dir" ]; then
    gtk-update-icon-cache -q -f "$dir" || true
  else
    as_root gtk-update-icon-cache -q -f "$dir" || true
  fi
}

# True while process $1 exists and is not a zombie (a zombie has already let go of
# everything: its D-Bus name, its Wayland surfaces).
alive() {
  local state
  state=$(cut -d' ' -f3 "/proc/$1/stat" 2>/dev/null) && [ "$state" != Z ]
}

# Replaces every running shell of this user with the installed one. Each new shell gets
# the environment its compositor gave the old one and the same arguments (both read from
# /proc), so this works from any terminal, over ssh or from a TTY. When none runs, it is
# started from this session.
restart_shell() {
  local bin=$prefix/bin/shelly uid pid entry var setsid_bin envdir
  local -a pids=() envs=() kept=() args=()
  uid=$(id -u)
  setsid_bin=$(command -v setsid) || die "--restart needs setsid (util-linux)"
  envdir=$(mktemp -d)

  mapfile -t pids < <(pgrep -u "$uid" -x shelly || true)
  if [ ${#pids[@]} -gt 0 ]; then
    for pid in "${pids[@]}"; do
      cp "/proc/$pid/environ" "$envdir/$pid.env" 2>/dev/null || true
      cp "/proc/$pid/cmdline" "$envdir/$pid.args" 2>/dev/null || true
    done
    say "Stopping the running shell (pid ${pids[*]})"
    kill -TERM "${pids[@]}" 2>/dev/null || true
    for _ in $(seq 50); do
      local any=0
      for pid in "${pids[@]}"; do alive "$pid" && any=1; done
      [ $any = 0 ] && break
      sleep 0.1
    done
    for pid in "${pids[@]}"; do
      if alive "$pid"; then
        kill -KILL "$pid" 2>/dev/null || true
      fi
    done
    sleep 0.2
  elif [ -n "${WAYLAND_DISPLAY:-}" ]; then
    env -0 >"$envdir/self.env"
  else
    warn "Shelly is not running and this is not a Wayland session, so it was not started"
    rm -rf "$envdir"
    return
  fi

  local log_dir=${XDG_STATE_HOME:-$HOME/.local/state}/shelly
  mkdir -p "$log_dir"
  local log=$log_dir/shelly.log
  : >"$log"
  for entry in "$envdir"/*.env; do
    [ -s "$entry" ] || continue
    mapfile -d '' envs <"$entry"
    kept=()
    for var in "${envs[@]}"; do
      case $var in
        SHELLY_DATA_DIR=*) ;; # A shell run from the build tree must not keep its data.
        [A-Za-z_]*=*) kept+=("$var") ;;
      esac
    done
    args=()
    if [ -s "${entry%.env}.args" ]; then
      mapfile -d '' args <"${entry%.env}.args"
      args=("${args[@]:1}") # Without argv[0]: the installed binary replaces whichever ran.
    fi
    env -i "${kept[@]}" "$setsid_bin" -f "$bin" "${args[@]}" >>"$log" 2>&1 </dev/null
  done
  rm -rf "$envdir"

  for _ in $(seq 20); do
    sleep 0.1
    pid=$(pgrep -n -u "$uid" -x shelly || true)
    [ -n "$pid" ] && break
  done
  sleep 1 # Long enough for a start-up failure (no compositor, already running) to show.
  pid=$(pgrep -n -u "$uid" -x shelly || true)
  if [ -n "$pid" ]; then
    say "Shelly is running (pid $pid, $(readlink "/proc/$pid/exe" 2>/dev/null || echo "$bin")); its output goes to $log"
  else
    warn "Shelly did not stay up. The end of $log:"
    tail -n 20 "$log" >&2 || true
    return 1
  fi
  if pgrep -u "$uid" -x shelly-settings >/dev/null; then
    note "Settings (shelly-settings) is still the old version; close and reopen it."
  fi
}

# ---- Dependencies ---------------------------------------------------------------------------

# What a source build needs, per package manager: the lists of README.md (Dependencies)
# without Catch2, since this build has no tests. Keep the two in step.
pacman_packages=(base-devel meson ninja python gtkmm-4.0 gtk4-layer-shell wayland wayland-protocols
  tomlplusplus nlohmann-json fontconfig libxkbcommon libepoxy wireplumber libsoup3 glib-networking
  libqalculate pam systemd-libs libevdev)
apt_packages=(build-essential pkg-config meson ninja-build python3
  libgtkmm-4.0-dev libgtk4-layer-shell-dev libwayland-dev libwayland-bin wayland-protocols
  libtomlplusplus-dev nlohmann-json3-dev libfontconfig-dev libxkbcommon-dev libepoxy-dev
  libwireplumber-0.5-dev libsoup-3.0-dev glib-networking libqalculate-dev
  libpam0g-dev libudev-dev libevdev-dev)
dnf_packages=(gcc-c++ meson ninja-build python3 gtkmm4.0-devel gtk4-layer-shell-devel wayland-devel
  wayland-protocols-devel tomlplusplus-devel json-devel fontconfig-devel libxkbcommon-devel
  libepoxy-devel wireplumber-devel libsoup3-devel glib-networking libqalculate-devel pam-devel
  systemd-devel libevdev-devel)

# Prints this system's package manager (pacman, apt or dnf), or nothing. package.sh has the
# same list.
package_manager() {
  if command -v pacman >/dev/null 2>&1; then
    echo pacman
  elif command -v apt-get >/dev/null 2>&1; then
    echo apt
  elif command -v dnf >/dev/null 2>&1; then
    echo dnf
  fi
}

# Installs those of the packages $2... that are missing, with the package manager $1. Asks
# for root only when something is missing. Without a terminal the package manager is not
# allowed to ask, so this also works from a dotfiles script.
install_packages() {
  local manager=$1 package
  local -a missing=() yes=()
  shift
  case $manager in
    pacman) mapfile -t missing < <(pacman -T -- "$@" 2>/dev/null || true) ;;
    apt)
      for package in "$@"; do
        [ "$(dpkg-query -W -f='${db:Status-Status}' "$package" 2>/dev/null || true)" = installed ] ||
          missing+=("$package")
      done
      ;;
    dnf)
      for package in "$@"; do
        rpm -q --whatprovides "$package" >/dev/null 2>&1 || missing+=("$package")
      done
      ;;
  esac
  if [ ${#missing[@]} -eq 0 ]; then
    say "Every dependency is already installed"
    return
  fi
  say "Installing ${#missing[@]} missing packages with $manager: ${missing[*]}"
  case $manager in
    pacman)
      [ -t 0 ] || yes=(--noconfirm)
      # Without -y on purpose: refreshing the lists without upgrading breaks an Arch system.
      as_root pacman -S --needed "${yes[@]}" -- "${missing[@]}" ||
        die "pacman could not install them. If it could not find or download a package, update the system first (sudo pacman -Syu) and run this again; --no-deps skips this step."
      ;;
    apt)
      [ -t 0 ] || yes=(-y)
      as_root apt-get install "${yes[@]}" -- "${missing[@]}" ||
        die "apt could not install them (README.md, Dependencies); --no-deps skips this step."
      ;;
    dnf)
      [ -t 0 ] || yes=(-y)
      as_root dnf install "${yes[@]}" -- "${missing[@]}" ||
        die "dnf could not install them (README.md, Dependencies); --no-deps skips this step."
      ;;
  esac
}

# Installs what a source build needs.
install_build_dependencies() {
  local manager
  manager=$(package_manager)
  case $manager in
    pacman) install_packages pacman "${pacman_packages[@]}" ;;
    apt) install_packages apt "${apt_packages[@]}" ;;
    dnf) install_packages dnf "${dnf_packages[@]}" ;;
    *) warn "found neither pacman, apt nor dnf, so no dependency was installed; README.md lists them" ;;
  esac
}

# Installs the packages a binary package says its programs need: $1 is the package manager
# they are named for, $2 the names, separated by spaces (package.sh wrote both).
install_runtime_dependencies() {
  local built_with=$1 manager package
  local -a packages=()
  read -r -a packages <<<"$2"
  manager=$(package_manager)
  if [ ${#packages[@]} -eq 0 ]; then
    note "This package does not say which packages it needs; the library check below still runs."
    return
  fi
  if [ "$manager" != "$built_with" ]; then
    warn "this package names its dependencies for $built_with, which is not this system's package manager, so none was installed"
    return
  fi
  for package in "${packages[@]}"; do
    [[ $package =~ ^[A-Za-z0-9][A-Za-z0-9+._:-]*$ ]] || die "PACKAGE names a dependency that is no package name: $package"
  done
  install_packages "$manager" "${packages[@]}"
}

# ---- Stage the files ------------------------------------------------------------------------

if [ -f "$here/PACKAGE" ] && [ -d "$here/root" ]; then
  field() { sed -n "s/^$1=//p" "$here/PACKAGE" | head -n 1; }
  package_prefix=$(field prefix)
  if [ -n "$prefix" ] && [ "$prefix" != "$package_prefix" ]; then
    die "this package was built for $package_prefix and cannot move (the data directory is compiled in). Make one for $prefix with: package.sh --prefix $prefix"
  fi
  prefix=$package_prefix
  if [ "$(field arch)" != "$(uname -m)" ]; then
    die "this package is for $(field arch), this machine is $(uname -m)"
  fi
  say "Installing Shelly $(field version) ($(field commit)), built on $(field built_on), into $prefix"
  if [ "$deps" = 1 ]; then
    install_runtime_dependencies "$(field package_manager)" "$(field depends)"
  fi
  if [ "$deps_only" = 1 ]; then exit 0; fi

  # A prebuilt binary runs only where its libraries are: in practice the distribution and
  # release it was built on. Say which ones are missing before anything is copied.
  missing=""
  while IFS= read -r -d '' file; do
    out=$(LC_ALL=C ldd "$file" 2>&1 || true)
    if grep -q 'not found' <<<"$out"; then
      missing+="$(grep 'not found' <<<"$out" | sed 's/^[[:space:]]*/    /')"$'\n'
    fi
  done < <(find "$here/root" -type f \( -path '*/bin/*' -o -path '*/libexec/*' \) -print0)
  if [ -n "$missing" ]; then
    printf '%s' "$missing" | sort -u >&2
    die "the prebuilt files do not fit this system (see above): they need the library versions of $(field built_on). Install them, or build here instead: run install.sh from a source package (package.sh --source) or a checkout."
  fi
  stage=$here/root
  if [ -n "$destdir" ]; then
    mkdir -p "$destdir"
    cp -a "$here/root/." "$destdir/"
    say "Staged into $destdir"
    exit 0
  fi

elif [ -f "$here/meson.build" ]; then
  prefix=${prefix:-/usr/local}
  build_dir=$(realpath -m "${build_dir:-$here/build-release}")
  if [ "$deps" = 1 ]; then
    install_build_dependencies
  fi
  if [ "$deps_only" = 1 ]; then exit 0; fi
  command -v meson >/dev/null 2>&1 || die "meson is not installed (README.md, Dependencies)"
  if [ "$(id -u)" = 0 ] && [ -n "${SUDO_USER:-}" ]; then
    warn "building as root leaves root-owned files in $build_dir; run install.sh as yourself, it asks for sudo itself"
  fi

  # Release build. Warnings stay warnings here: a newer compiler on the target should not
  # refuse to install. Development builds keep -Dwerror=true (NFR-08).
  options=(
    -Dprefix="$prefix"
    -Dsysconfdir=/etc # PAM reads /etc/pam.d only (README.md).
    -Dbuildtype=release
    -Dwerror=false
    -Dtests=disabled
  )
  if [ -f "$build_dir/meson-private/coredata.dat" ]; then
    say "Configuring $build_dir for $prefix"
    meson configure "$build_dir" "${options[@]}"
  else
    say "Setting up $build_dir for $prefix"
    meson setup "$build_dir" "$here" "${options[@]}"
  fi
  say "Building"
  meson compile -C "$build_dir"

  if [ -n "$destdir" ]; then
    stage=$(realpath -m "$destdir")
    mkdir -p "$stage"
  else
    stage=$(mktemp -d)
    trap 'rm -rf "$stage"' EXIT
  fi
  meson install -C "$build_dir" --no-rebuild --quiet --destdir "$stage"
  if [ -n "$destdir" ]; then
    say "Staged into $stage"
    exit 0
  fi

else
  die "found neither a package (PACKAGE and root/) nor a source tree (meson.build) beside $0"
fi

# ---- Install ------------------------------------------------------------------------------

deploy "$stage"
refresh_icon_cache

case ":$PATH:" in
  *":$prefix/bin:"*) ;;
  *) note "$prefix/bin is not on your PATH; the compositor needs it there to start 'shelly'." ;;
esac
case ":${XDG_DATA_DIRS:-/usr/local/share:/usr/share}:" in
  *":$prefix/share:"* | *":$prefix/share/:"*) ;;
  *) note "$prefix/share is not in XDG_DATA_DIRS, so launchers will not list Settings." ;;
esac

if [ "$restart" = 1 ]; then
  restart_shell
else
  if pgrep -u "$(id -u)" -x shelly >/dev/null 2>&1; then
    note "The running shell is still the old version: run install.sh --restart, or restart it yourself."
  fi
fi
