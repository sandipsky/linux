# Third-party notices

Material in Shelly that comes from other projects (`REF-21`). Update this file in the same change that adds or ports anything.

## Bundled in this repository

### Tabler Icons — `assets/tabler.ttf`

- **What:** the icon font for every UI glyph (`DS-30`). Supplied by the project owner; installed as `share/shelly/fonts/tabler-icons.ttf`.
- **Origin:** byte-identical to `lib/assets/fonts/noctalia-tabler.ttf` in the Noctalia v5.5.0 checkout (SHA-256 `352fffc1e9024e5a1ddb5fbf9db532dae793839ae338b6e8234f32e792a8723c`). It is a build of [Tabler Icons](https://tabler.io/icons) made with svg2ttf. Its name table reads family `noctalia-tabler-icons`, "Version 1.0".
- **Tabler version:** not recorded in the font, nor anywhere in the reference checkout. It holds 4950 outline and 979 filled glyphs.
- **Licence:** MIT.

```
MIT License

Copyright (c) 2020-2025 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Settings application icon — `assets/settings.svg`

- **What:** the application icon of `shelly-settings` (desktop entry and window icon). Supplied by the project owner; installed as `share/icons/hicolor/scalable/apps/io.shelly.Settings.svg`.
- **Origin:** the GNOME Settings application icon, a work of the GNOME project, as confirmed by the owner (`docs/DECISIONS.md`, D33).
- **Source:** `data/icons/hicolor/scalable/apps/org.gnome.Settings.svg` in gnome-control-center, <https://gitlab.gnome.org/GNOME/gnome-control-center>.
- **Licence:** GPL-2.0-or-later, the licence of gnome-control-center (its `meson.build` declares `GPL2+`; `COPYING` is the GPL version 2 text). Upstream states no separate licence for the icon, and the SVG carries no licence or copyright text of its own (checked 2026-11-16). This one file stays under the GPL; the rest of Shelly is MIT.
- **Copyright:** the GNOME Project and the gnome-control-center contributors. Upstream names no individual holder for this file. Accepted by the owner (`docs/DECISIONS.md`, D58).

### fzy — `src/core/fuzzy_match.cpp`

- **What:** the fuzzy scorer of the launcher (`LCH-04`), ported to C++ from the copy the reference vendors in `third_party/fzy` (`match.c`, `bonus.h`, `config.h`). The reference's wrapper (`src/launcher/fuzzy_match.cpp`) is ported with it.
- **Origin:** <https://github.com/jhawthorn/fzy>.
- **Licence:** MIT.

```
The MIT License (MIT)

Copyright (c) 2014 John Hawthorn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

### Launcher widget SVGs — `data/icons/launcher/`

`shell.svg`, `shell-symbolic.svg` and `orbit-symbolic.svg` were drawn for Shelly (M4, D151) and are under Shelly's own licence. No third-party artwork.

## Ported or copied from Noctalia

Noctalia v5 is the reference implementation (§2 of the requirements). It is MIT-licensed:

```
MIT License

Copyright (c) 2026 noctalia-dev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

What Shelly takes from it. Every ported file carries a notice in its header pointing here.

| In Shelly | From the reference | Kind |
|---|---|---|
| Accent colour values in `data/css/tokens.css` | `src/theme/builtin_palettes.cpp`, the "Noctalia" dark palette | Ten colour values (`DS-11`) |
| `.clang-format` | `.clang-format` | Formatter configuration, copied whole |
| Colour role names (`primary`, `surface_container`, …) | `lib/ui/palette.h` | Names only |
| `src/core/time_format.cpp` | `src/time/time_format.cpp` | Ported: the clock's format language (M1) |
| `src/services/app_identity.cpp` | `src/system/app_identity.cpp`, the icon lookup of `src/shell/bar/widgets/active_window_widget.cpp` | Ported: matching a window to its application (M1) |
| `src/compositor/hyprland/hyprland_model.cpp` | `src/compositors/hyprland/hyprland_workspace_backend.cpp` | Ported: Hyprland's reply schemas, identities, rules, urgency and order (M1) |
| `src/compositor/niri/niri_model.cpp` | `src/compositors/niri/niri_workspace_backend.cpp` | Ported: parsing of niri's events (M1) |
| `src/compositor/mango/mango_model.cpp` | `src/compositors/mango/mango_workspace_backend.cpp` | Ported: Mango's monitor and tag model (M1) |
| `src/core/scroll.hpp` | `lib/ui/input_area.cpp` | Thresholds only: touchpad steps (M1) |
| `src/core/sysmon.cpp` | `src/system/cpu_stat.cpp`, `src/system/system_monitor_service.cpp` | Ported: the CPU delta, `/proc/meminfo`, the ZFS cache, the tint ramp (M3) |
| `src/core/audio.cpp`, `src/services/audio_service.cpp` | `src/pipewire/audio_glyphs.cpp`, `pipewire_service.cpp`, `wireplumber_mixer.cpp` | Ported: glyphs, scroll step, WirePlumber mixer use (M3) |
| `src/core/battery.cpp`, `src/services/upower_service.cpp`, `power_profiles_service.cpp`, `brightness_service.cpp` | `src/dbus/upower/upower_service.cpp`, `src/dbus/power/power_profiles_service.cpp`, `src/system/brightness_service.cpp` | Ported: battery glyphs, thresholds and selection, profiles, backlight discovery and writes (M3) |
| `src/core/network.cpp`, `src/services/network_service.cpp`, `src/services/rfkill.cpp` | `src/dbus/network/network_display.cpp`, `network_manager_security.h`, `network_manager_service.cpp`, `network_secret_agent.cpp`, `src/system/rfkill_helper.cpp` | Ported: glyphs, security, merging, connection and secret-agent logic, failure texts, rfkill (M3) |
| `src/core/bluetooth.cpp`, `src/core/bluetooth_uuid.cpp`, `src/services/bluetooth_service.cpp` | `src/dbus/bluetooth/bluetooth_service.cpp`, `bluetooth_agent.cpp`, `bluetooth_uuid_names.cpp`, `src/shell/control_center/tabs/bluetooth_tab.cpp` | Ported: classification, the service-name table, the agent, order (M3) |
| `src/core/weather.cpp`, `src/services/weather_service.cpp` | `src/system/weather_service.cpp`, `src/shell/bar/widgets/weather_widget.cpp` | Ported: weather codes, glyphs, conversions, parsing, refresh and retry (M3) |
| `protocols/wlr-foreign-toplevel-management-unstable-v1.xml` | `protocols/` | Copied unchanged; see below |
| `protocols/wlr-output-management-unstable-v1.xml` | `protocols/` | Copied unchanged; see below (M3) |
| `src/core/launcher.cpp`, `src/services/launcher_service.cpp`, `src/services/app_index.cpp` (launcher entries), `src/ui/panels/launcher_panel.cpp` | `src/launcher/app_provider.cpp`, `src/shell/launcher/launcher_panel.cpp`, `src/system/desktop_entry_launch.cpp`, `src/system/terminal_launch.cpp` | Ported: scoring, usage boost, Exec handling, terminal wrapping, D-Bus activation, the Simple layout (M4) |
| `src/core/fuzzy_match.cpp` | `src/launcher/fuzzy_match.cpp` and the vendored fzy (above) | Ported (M4) |
| `src/services/calculator.cpp` | `src/launcher/math_provider.cpp` | Ported: libqalculate set-up and evaluation (M4) |
| `src/services/session_service.cpp`, the log-out requests of the three backends | `src/shell/session/session_action_runner.cpp`, `session_action_meta.cpp`, `src/compositors/compositor_platform.cpp` | Ported: command lists, log-out chain, glyphs (M4) |
| `src/core/clipboard.cpp`, `src/services/clipboard_service.cpp`, `src/services/data_control.cpp`, `src/services/virtual_keyboard.cpp`, `src/ui/panels/clipboard_panel.cpp` | `src/shell/wayland/clipboard_service.cpp`, `clipboard_globals.cpp`, `virtual_keyboard_service.cpp`, `src/shell/clipboard/clipboard_panel.cpp`, `clipboard_paste.cpp` | Ported: MIME choice, history rules, manifest, re-offering, auto-paste, the panel (M4) |
| `src/core/calendar.cpp`, `src/core/time_format.cpp` (`locale_first_weekday`), `src/ui/widgets/clock/calendar_popup.cpp` | `src/shell/calendar/calendar_view.cpp`, `src/shell/control_center/tabs/calendar_tab.cpp`, `src/time/time_format.cpp` | Ported: the month grid, week numbers, the first weekday (M4) |
| `protocols/wlr-data-control-unstable-v1.xml`, `protocols/virtual-keyboard-unstable-v1.xml` | `protocols/` | Copied unchanged; see below (M4) |
| `src/core/notifications.cpp`, `src/services/notification_service.cpp` | `src/notification/notification_manager.cpp`, `notification_filter.cpp`, `notification_display_name.cpp`, `notification_history_store.cpp`, `src/dbus/notification/notification_service.cpp`, `lib/util/string_utils.h` (`sanitizeMarkup`) | Ported: ingest rules, markup removal, filters, the manager, the history layout, display names (M5) |
| `src/core/toast_stack.cpp`, `src/ui/notifications/toast_manager.cpp` | `src/shell/notification/notification_toast.cpp` | Ported: placement, queue, `max_visible`, collapse; surfaces and their offsets (M5) |
| `src/core/osd.cpp`, `src/services/lock_keys_service.cpp`, `src/ui/osd/osd_manager.cpp` | `src/shell/osd/osd_overlay.cpp`, `audio_osd.cpp`, `brightness_osd.cpp`, `lock_keys_osd.cpp`, `src/system/lock_keys_service.cpp`, `src/app/application_internal.h` | Ported: OSD content, trigger rules, lock-key LEDs, anchors (M5) |
| `src/ui/wallpaper/gl_renderer.cpp` | `src/shell/render/programs/wallpaper_program.cpp`, `wallpaper_sampling_glsl.h`, `lib/render/programs/blur_program.cpp`, `src/shell/backdrop/wallpaper_renderer.cpp` | Ported: the twelve transition shaders and the fill-mode sampling verbatim, the blur shader, the backdrop's blur and tint passes (M6) |
| `src/core/wallpaper.cpp`, `src/services/wallpaper_service.cpp`, `src/ui/wallpaper/wallpaper_surface.cpp`, `wallpaper_manager.cpp` | `src/shell/wallpaper/wallpaper.cpp`, `wallpaper_geometry.cpp`, `wallpaper_shuffle_state.cpp`, `wallpaper_paths.cpp`, `lib/render/core/shared_texture_cache.cpp`, `lib/render/codecs/thumbnail_service.cpp`, `lib/util/string_utils.h` (natural order), `src/shell/backdrop/backdrop.cpp` | Ported: transition parameters, the switching rules, span and coverage, halving, the slideshow's picks and shuffle memory, the thumbnail cache key, the backdrop (M6) |
| `src/pam_helper/pam_helper_main.cpp`, `src/pam_helper/protocol.hpp`, `src/services/pam_authenticator.cpp` | `src/auth/pam_helper_main.cpp`, `pam_helper_protocol.h`, `pam_authenticator.cpp` | Ported: the PAM conversation, the account and credential steps, the wire protocol (with the message text added), the judging of the helper's answer (M7) |
| `src/services/fingerprint_service.cpp` | `src/auth/fingerprint_authenticator.cpp` | Ported: fprintd's claim, verify and retry logic and its messages (M7) |
| `src/services/login_session.cpp` | `src/dbus/logind/logind_service.cpp` | Ported: session lookup, Lock and Unlock, `LockedHint`, the sleep delay inhibitor (M7) |
| `src/services/screen_capture.cpp`, `src/core/lock.cpp` (captures) | `src/capture/screencopy_capture.cpp`, `screencopy_util.cpp` | Ported: the shared-memory capture, the pixel formats, turning a capture upright (M7) |
| `src/ui/wallpaper/gl_renderer.cpp` (the cover program) | `src/shell/render/programs/lockscreen_transition_program.cpp` | Ported: the lock transition shader, verbatim (M7) |
| `src/core/lock.cpp`, `src/ui/lock/lock_screen.cpp`, `lock_window.cpp` | `src/shell/lockscreen/lock_screen.cpp`, `lock_surface.cpp`, `lockscreen_session_actions.cpp`, `src/app/application_services.cpp`, `application_ui.cpp` | Ported: the transition choice and parameters, the grace window, the status rules, the lock and unlock sequence, lock before sleep, Do Not Disturb while locked (M7) |
| `protocols/wlr-screencopy-unstable-v1.xml` | `protocols/` | Copied unchanged; see below (M7) |
| `src/core/idle.cpp`, `src/services/idle_service.cpp` | `src/idle/idle_manager.cpp` | Ported: idle notifications per timeout, the ScreenSaver release debounce and the restart of countdowns at a release (M8) |
| `src/services/screensaver_service.cpp` | `src/dbus/idle/screensaver_service.cpp` | Ported: `org.freedesktop.ScreenSaver` at both paths, sender tracking, logind's idle block (M8) |
| The screen power requests of the three backends | `src/compositors/hyprland/hyprland_output_backend.cpp`, `niri/niri_output_backend.cpp`, `mango/mango_output_backend.cpp` | Ported: `dpms`, `PowerOffMonitors` and `PowerOnMonitors`, `sleep_monitor` and `wakeup_monitor` (M8) |
| `src/core/night_light.cpp`, `src/services/night_light_service.cpp` | `src/system/day_night_schedule.cpp`, `src/system/gamma_service.cpp`, `src/config/schema/config_schema_system.cpp`, `src/shell/settings/settings_registry_location.cpp` | Ported: sunrise and sunset, the schedule, the centred one-hour fade, the colour of a temperature and its gamma ramp, the day-and-night rule, the linked sliders (M8) |
| `protocols/wlr-gamma-control-unstable-v1.xml` | `protocols/` | Copied unchanged; see below (M8) |

## Wayland protocol XML

`protocols/wlr-foreign-toplevel-management-unstable-v1.xml` is the wlroots protocol, copied from the reference's `protocols/` directory unchanged. Its own notice, which the file keeps:

```
Copyright © 2018 Ilia Bozhinov

Permission to use, copy, modify, distribute, and sell this
software and its documentation for any purpose is hereby granted
without fee, provided that the above copyright notice appear in
all copies and that both that copyright notice and this permission
notice appear in supporting documentation, and that the name of
the copyright holders not be used in advertising or publicity
pertaining to distribution of the software without specific,
written prior permission.  The copyright holders make no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied
warranty.
```

`protocols/wlr-output-management-unstable-v1.xml` is the wlroots protocol, copied from the reference's `protocols/` directory unchanged. Its own notice, which the file keeps:

```
Copyright © 2019 Purism SPC

Permission to use, copy, modify, distribute, and sell this
software and its documentation for any purpose is hereby granted
without fee, provided that the above copyright notice appear in
all copies and that both that copyright notice and this permission
notice appear in supporting documentation, and that the name of
the copyright holders not be used in advertising or publicity
pertaining to distribution of the software without specific,
written prior permission.  The copyright holders make no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied
warranty.
```

`protocols/wlr-data-control-unstable-v1.xml` is the wlroots protocol, copied from the reference's `protocols/` directory unchanged (M4). Its own notice, which the file keeps:

```
Copyright © 2018 Simon Ser
Copyright © 2019 Ivan Molodetskikh

Permission to use, copy, modify, distribute, and sell this
software and its documentation for any purpose is hereby granted
without fee, provided that the above copyright notice appear in
all copies and that both that copyright notice and this permission
notice appear in supporting documentation, and that the name of
the copyright holders not be used in advertising or publicity
pertaining to distribution of the software without specific,
written prior permission.  The copyright holders make no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied
warranty.
```

`protocols/virtual-keyboard-unstable-v1.xml` is the virtual-keyboard protocol, copied from the reference's `protocols/` directory unchanged (M4). Its own notice, which the file keeps:

```
Copyright © 2008-2011 Kristian Høgsberg
Copyright © 2010-2013 Intel Corporation
Copyright © 2012-2013 Collabora, Ltd.
Copyright © 2018 Purism SPC

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice (including the next
paragraph) shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

The ext-* protocols (ext-workspace-v1, ext-data-control-v1, ext-idle-notify-v1) are not copied: they come from the system's wayland-protocols at build time.

`protocols/wlr-screencopy-unstable-v1.xml` is the wlroots protocol, copied from the reference's `protocols/` directory unchanged (M7). Its own notice, which the file keeps:

```
Copyright © 2018 Simon Ser
Copyright © 2019 Andri Yngvason

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice (including the next
paragraph) shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

`protocols/wlr-gamma-control-unstable-v1.xml` is the wlroots protocol, copied from the reference's `protocols/` directory unchanged (M8). Its own notice, which the file keeps:

```
Copyright © 2015 Giulio camuffo
Copyright © 2018 Simon Ser

Permission to use, copy, modify, distribute, and sell this
software and its documentation for any purpose is hereby granted
without fee, provided that the above copyright notice appear in
all copies and that both that copyright notice and this permission
notice appear in supporting documentation, and that the name of
the copyright holders not be used in advertising or publicity
pertaining to distribution of the software without specific,
written prior permission.  The copyright holders make no
representations about the suitability of this software for any
purpose.  It is provided "as is" without express or implied
warranty.

THE COPYRIGHT HOLDERS DISCLAIM ALL WARRANTIES WITH REGARD TO THIS
SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY
SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.
```

`protocols/wlr-output-power-management-unstable-v1.xml` is the wlroots protocol, which the reference does not carry: it was taken unchanged from upstream wlr-protocols (`https://gitlab.freedesktop.org/wlroots/wlr-protocols`, `unstable/`) in M8. Its own notice, which the file keeps:

```
Copyright © 2019 Purism SPC

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice (including the next
paragraph) shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

## Data services

| Service | Used for | Terms |
|---|---|---|
| [Open-Meteo](https://open-meteo.com/) forecast API | The Weather widget (`WX-03`) | Data under CC BY 4.0; credited on the Weather sub-page (D139) |
| Open-Meteo geocoding API, with data from [GeoNames](https://www.geonames.org/) | The location search in Settings (`WX-01`) | GeoNames data under CC BY 4.0; credited on the same line |

## Linked at build time, not bundled

Shelly links these as system libraries. They are not distributed with Shelly's source; their licences apply to whoever distributes binaries.

| Library | Used for | Licence |
|---|---|---|
| GTK 4, gtkmm 4, glibmm, libsigc++ | UI toolkit, main loop, signals | LGPL-2.1-or-later |
| gtk4-layer-shell | Layer surfaces and session lock | MIT |
| toml++ | Reading and writing `config.toml` | MIT |
| Fontconfig | Registering the icon font privately | MIT-style (Fontconfig licence) |
| Catch2 (tests only) | Unit tests | BSL-1.0 |
| wayland-client, wayland-protocols, wayland-scanner | Extra Wayland protocols | MIT |
| nlohmann/json (header-only) | Compositor IPC, Open-Meteo responses | MIT |
| WirePlumber (libwireplumber-0.5), PipeWire | Audio | MIT |
| libsoup 3 | HTTP for weather and the place search | LGPL-2.0-or-later |
| libqalculate | The launcher's calculator (`LCH-05`) | **GPL-2.0-or-later.** The reference links it too. A distributed `shelly` binary therefore falls under the GPL's terms; Shelly's own source stays MIT. |
| xkbcommon | The keymap of clipboard auto-paste | MIT |
| Linux-PAM (libpam) | `shelly-pam-helper` only (`LOCK-06`) | BSD-3-Clause or GPL-2.0-or-later, at the user's choice |
| libudev (systemd) | Finding game controllers and their hot-plugging (`PWR-21`) | LGPL-2.1-or-later |
| libevdev | Reading game controller input (`PWR-20`, `PWR-22`) | MIT |
